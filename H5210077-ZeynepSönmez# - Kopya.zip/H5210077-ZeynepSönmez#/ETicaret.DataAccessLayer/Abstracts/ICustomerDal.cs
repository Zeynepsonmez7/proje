﻿using ETicaret.EntityLayer.Concretes;

namespace ETicaret.DataAccessLayer.Abstracts
{
    public interface ICustomerDal : IGenericDal<Customer>
    {

    }

}
