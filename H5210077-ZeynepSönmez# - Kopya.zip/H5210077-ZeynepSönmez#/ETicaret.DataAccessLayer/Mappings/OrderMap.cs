﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using ETicaret.EntityLayer.Concretes;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using System.Threading.Tasks;

namespace ETicaret.DataAccessLayer.Mappings
{
    /// <summary>
    /// Customer entity veritabanı modellemesi
    /// </summary>
    public class OrderMap : IEntityTypeConfiguration<Order>
    {

        public void Configure(EntityTypeBuilder<Order> modelBuilder)
            {
                    modelBuilder.ToTable("Order");
                    modelBuilder.HasKey(x => x.OrderId);

                    modelBuilder.Property(x => x.OrderName).HasColumnType("nvarchar").HasMaxLength(100).IsRequired();

                    modelBuilder.Property(x => x.OrderStatus).HasDefaultValue(true);

                    modelBuilder.Property(x => x.OrderDescription).HasColumnType("nvarchar").HasMaxLength(100).IsRequired();


                    modelBuilder.Property(x => x.ProductId).HasColumnType("int").HasMaxLength(500).IsRequired();

            }
        }
}













// Cutomer tablosundad veri yoksa aşağıdaki veriyi kaydet oluyor...
//modelBuilder.HasData(new Customer
//            {
//                CustomerId = 1,
//                CustomerEmail = "tt@gmail.com",
//                CustomerLastName = "Tanin",
//                CustomerName = "Tuncay",
//                CreateDate = DateTime.Now,
//                CustomerUserName = "tt",
//                BirthDay = Convert.ToDateTime("2000-01-01"),
//                CustomerStatus = true,
//                PhoneNumber = "+905327411235"
//            });
            //modelBuilder.Entity<Adress>()
            //    .ToTable("Adresler")
            //    .Property(x => x.AdressName).HasMaxLength(50).IsRequired();

//        }
//    }
//}

//        }