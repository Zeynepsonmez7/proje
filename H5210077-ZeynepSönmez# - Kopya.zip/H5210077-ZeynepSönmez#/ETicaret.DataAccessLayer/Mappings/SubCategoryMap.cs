﻿using ETicaret.EntityLayer.Concretes;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace ETicaret.DataAccessLayer.Mappings
{
    public  class SubCategoryMap : IEntityTypeConfiguration<SubCategory>
    {
        public void Configure(EntityTypeBuilder<SubCategory> builder)
        {
            builder.ToTable("SubCategory");
            builder.HasKey(x => x.SubCategoryId);
            builder.Property(x => x.SubCategoryName).HasColumnType ("nvarchar").HasMaxLength(100).IsRequired();
          
            builder.Property(x => x.SubCategoryStatu).HasDefaultValue(true);
            builder.Property(x => x.CategoryId).HasColumnType("int").HasMaxLength(300).IsRequired();

        }

    }
}
