﻿using ETicaret.EntityLayer.Concretes;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Json;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Eticaret.Desktop
{
    public partial class FormSubCategory : Form
    {
        private string url = "https://localhost:44374/api/";
        public FormSubCategory()
        {
            InitializeComponent();
            Load += FormSubCategory_Load;
        }
        private async Task AltKategoriListele()
        {
            using (HttpClient httpClient = new HttpClient())
            {
                var subCategories = await httpClient.GetFromJsonAsync<List<SubCategory>>(new Uri(url + "SubCategory/GetList"));
                dtgvSubCategorys.DataSource = subCategories;
            }
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private async void btnEkle_Click(object sender, EventArgs e)
        {
            SubCategory subCategory = new SubCategory()
            {
                SubCategoryName = categoryName.Text,
                SortKey = 1, 
                SubCategoryStatu = radioButton1.Checked,
                CategoryId = listBox1.SelectedIndex
                
            };

            using (HttpClient httpClient = new HttpClient())
            {
                HttpResponseMessage responseMessage = await httpClient.PostAsJsonAsync(url + "SubCategory/Add/", subCategory);
                if (responseMessage.IsSuccessStatusCode)
                {
                    await AltKategoriListele();
                    //FormClear();
                }
            }
        }

        private async void FormSubCategory_Load(object sender, EventArgs e)
        {
            await AltKategoriListele();
        }
        private void btnTemizle_Click(object sender, EventArgs e)
        {
            FormClear();
        }

        private void FormClear()
        {
            categoryName.Text = String.Empty;
           

        }

        private void txtSubCategoryId_TextChanged(object sender, EventArgs e)
        {
            ButonlarKontrolu();
        }

        private void ButonlarKontrolu()
        {
            bool aktifEt = false;
            if (!string.IsNullOrEmpty(txtSubCategoryId.Text))
            {
                if (int.Parse(txtSubCategoryId.Text) > 0)
                {
                    aktifEt = true;

                }
            }
            btnSil.Enabled = aktifEt;
            btnGuncelle.Enabled = aktifEt;
        }
        private async void btnSil_Click(object sender, EventArgs e)
        {
            using (HttpClient httpClient = new HttpClient())
            {
                await httpClient.DeleteAsync(url + "SubCategory/Delete/" + txtSubCategoryId.Text);
                await AltKategoriListele();
            }
        }


        private void dtgvSubCategorys_RowHeaderMouseDoubleClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            txtSubCategoryId.Text = dtgvSubCategorys.CurrentRow.Cells[0].Value.ToString();
            categoryName.Text = dtgvSubCategorys.CurrentRow.Cells["SubCategoryName"].Value.ToString();
            radioButton1.Text = dtgvSubCategorys.CurrentRow.Cells["SubCategoryStatu"].Value.ToString();
            listBox1.SelectedItem = dtgvSubCategorys.CurrentRow.Cells["CategoryId"].Value.ToString();
            
        }


        private async void btnGuncelle_Click(object sender, EventArgs e)
        {
            SubCategory subCategory = new SubCategory()
            {
                SubCategoryName = categoryName.Text,
                SortKey = 1, 
                SubCategoryStatu = radioButton1.Checked,
                CategoryId = listBox1.SelectedIndex
            };

            using (HttpClient httpClient = new HttpClient())
            {
                HttpResponseMessage responseMessage = await httpClient.PutAsJsonAsync(url + "SubCategory/Update/", subCategory);
                if (responseMessage.IsSuccessStatusCode)
                {
                    await AltKategoriListele();
                    FormClear();
                }
            }
        }

   

        private void FormSubCategory_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            txtSubCategoryId.Text = dtgvSubCategorys.CurrentRow.Cells[0].Value.ToString();
            categoryName.Text = dtgvSubCategorys.CurrentRow.Cells["SubCategoryName"].Value.ToString();
            radioButton1.Text = dtgvSubCategorys.CurrentRow.Cells["SubCategoryStatu"].Value.ToString();
            listBox1.SelectedItem = dtgvSubCategorys.CurrentRow.Cells["CategoryId"].Value.ToString();

        }
    }
}
